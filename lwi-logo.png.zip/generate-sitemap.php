<?php

$domain = "https://www.ladangwohijo.com";
$dir = "./";

$files = glob($dir . "*.html");

$xml = '<?xml version="1.0" encoding="UTF-8"?>';
$xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

foreach ($files as $file) {

    $lastmod = date("Y-m-d", filemtime($file));

    $url = str_replace("./", "", $file);

    $xml .= "
    <url>
        <loc>$domain/$url</loc>
        <lastmod>$lastmod</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>";
}

$xml .= '</urlset>';

file_put_contents("sitemap.xml", $xml);

echo "Sitemap berhasil dibuat!";
?>